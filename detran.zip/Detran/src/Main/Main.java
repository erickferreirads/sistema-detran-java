package Main;
import java.util.*;

public class Main{
public static void main(String[]args){
		
	Emplacamento e = new Emplacamento();
	Carro c = new Carro();
	//	c.Ano();
	//	c.Proprietario();
	//	c.Cor();
	//	c.Marca();
	//	c.Modelo();
	//	c.CPF();
	//	c.exibirDados();
		//e.novoEmplacamento();
		e.placaChar();
		
			
		
	}

}

package Main;
import java.util.*;

public class Emplacamento {
	
	
	
	static Scanner sc = new Scanner(System.in);
	Carro c = new Carro();
	
	
	public Emplacamento() {
		System.out.println("Bem vindo ao Sistema de Emplacamento");
		
		
		
	}
	
	
	public boolean novoEmplacamento() {
		System.out.print("Placa antiga? (true/false): ");
		return sc.nextBoolean();
	}

	public void placaChar() {
		
		
		
		
		if (novoEmplacamento()) {
			
			char [] placa = new char [3];
			int [] placaInt = new int [4];
			sc.nextLine();
			
			for (int i = 0; i < 3; i++) {
				
				System.out.print("Digite os caracteres alfabéticos da placa: (3 caracteres) ");
				char q2 = sc.nextLine().charAt(0);
				placa[i] = q2;
				System.out.println(Arrays.toString(placa).toUpperCase());
			
			
				}
			for (int k = 0; k < 4; k++) {
			
				System.out.println("Digite of caracteres númericos da placa: (4 caracteres): ");
				int q = sc.nextInt();
				placaInt[k] = q;
				System.out.println(Arrays.toString(placaInt));
				
				
				
			}
				
				
			System.out.println("PLACA : " + Arrays.toString(placa).toUpperCase() + (Arrays.toString(placaInt)));
			
			
			
		} else {
			char [] placa = new char[3];
			int [] placaInt = new int[4];
			char[] placaCharInt = new char[4];
			char [] placaChar = {'A', 'B', 'C', 'D' , 'E', 'F', 'G', 'H', 'I', 'J'};
	
			sc.nextLine();
			
			for (int i = 0; i < 3; i++) {
				
				System.out.print("Digite os caracteres alfabéticos da placa: (3 caracteres) ");
				char q2 = sc.nextLine().charAt(0);
				placa[i] = q2;
				System.out.println(Arrays.toString(placa).toUpperCase());
			
			
				}
			for (int k = 0; k < 4; k++) {
			
				System.out.println("Digite of caracteres númericos da placa: (4 caracteres): ");
				int q = sc.nextInt();
				placaInt[k] = (char) q;
				placaCharInt[k] = (char) placaInt[k];
				System.out.println(Arrays.toString(placaCharInt));
							
				
					if (placaCharInt[1] == 0) {
						placaCharInt[1] = placaChar[0];
					}
					else if(placaCharInt[1] == 1) {
						placaCharInt[1] = placaChar[1];
					}
					else if(placaCharInt[1] == 2) {
						placaCharInt[1] = placaChar[2];
					}
					else if(placaCharInt[1] == 3) {
						placaCharInt[1] = placaChar[3];
					}
					else if(placaCharInt[1] == 4) {
						placaCharInt[1] = placaChar[4];
					}
					else if(placaCharInt[1] == 5) {
						placaCharInt[1] = placaChar[5];
					}
					else if(placaCharInt[1] == 6) {
						placaCharInt[1] = placaChar[6];
					}
					else if(placaCharInt[1] == 7) {
						placaCharInt[1] = placaChar[7];
					}
					else if(placaCharInt[1] == 8) {
						placaCharInt[1] = placaChar[8];
					}
					else if(placaCharInt[1] == 9) {
						placaCharInt[1] = placaChar[9];
					}
				
				
				
			}
				
				
			System.out.println("PLACA : " + Arrays.toString(placa).toUpperCase() + (Arrays.toString(placaInt)) + Arrays.toString(placaCharInt));
			System.out.println("PLACA : " + Arrays.toString(placa).toUpperCase() + (Arrays.toString(placaInt)));
			
			
			
				
			}
		}

	}


package Main;

public class Proprietario {

}
